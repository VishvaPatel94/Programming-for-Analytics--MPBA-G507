# Function to add two numbers

def add_two(a,b):
    '''Function to add two numbers'''
    return a+b

# Function to subtract two numbers

def sub_two(a,b):
    '''Function to subtract two numbers'''
    return a-b

def mul_two(a,b):
    '''Function to multiply two numbers'''
    return a*b

def pow_two(a,b):
    '''Function to power of a over b '''
    return a**b