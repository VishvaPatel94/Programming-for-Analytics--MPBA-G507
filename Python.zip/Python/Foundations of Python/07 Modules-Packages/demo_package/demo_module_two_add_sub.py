# Function to add two numbers

def demo_add_two(a,b):
    '''Function to add two numbers'''
    return a+b

# Function to subtract two numbers

def demo_sub_two(a,b):
    '''Function to subtract two numbers'''
    return a-b