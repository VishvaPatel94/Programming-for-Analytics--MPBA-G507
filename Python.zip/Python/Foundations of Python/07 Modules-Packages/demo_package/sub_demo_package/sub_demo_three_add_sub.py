# Functions to add/subtract two/two numbers

def demo_add_three(a,b,c):
    '''Function to add three numbers'''
    return a+b+c

# Function to subtract three numbers

def demo_sub_three(a,b,c):
    '''Function to subtract three numbers'''
    return a-b-c